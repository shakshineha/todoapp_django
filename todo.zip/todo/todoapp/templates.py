<h2>todo list</h2>
<h2>todo list</h2>
 
{% for x in items %}
<p>{{ x.name }} - {{ x.created|date:"D d M Y" }}</p>
 
<p>{{ x.description }}</p>
<hr />
{% endfor %}