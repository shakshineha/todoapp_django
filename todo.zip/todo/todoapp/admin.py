from django.contrib import admin
from django.contrib import admin 
from models import todoapp
 
admin.site.register(todoapp)